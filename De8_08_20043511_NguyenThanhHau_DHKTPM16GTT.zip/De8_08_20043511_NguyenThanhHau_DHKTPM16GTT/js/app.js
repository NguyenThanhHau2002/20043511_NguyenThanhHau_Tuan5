$(document).ready(function name(params) {
    $("#btnDK").click(function(){
        $("#myModal").modal();
    })
})
$(document).ready(function name(params) {
    $("#btnDN").click(function(){
        $("#myModal1").modal();
    })
})
